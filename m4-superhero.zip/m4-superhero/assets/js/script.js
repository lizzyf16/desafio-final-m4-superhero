window.onload = function() {

    var chart = new CanvasJS.Chart("chartSuperhero", {
        theme: "light2", // "light1", "light2", "dark1", "dark2"
        exportEnabled: true,
        animationEnabled: true,
        title: {
            text: "Estadísticas de poder para ",
            text2: "X"
        },
        data: [{
            type: "pie",
            startAngle: 25,
            toolTipContent: "<b>{label}</b>: {y}%",
            showInLegend: "true",
            legendText: "{label}",
            indexLabelFontSize: 16,
            indexLabel: "{label} - {y}%",
            dataPoints: [
                { y: 51.08, label: "Chrome" },
                { y: 27.34, label: "Internet Explorer" },
                { y: 10.62, label: "Firefox" },
                { y: 5.02, label: "Microsoft Edge" },
                { y: 4.07, label: "Safari" },
                { y: 1.22, label: "Opera" },
                { y: 0.44, label: "Others" }
            ]
        }]
    });

    chart.render();
    
    }

    $.ajax({
        url: "https://www.superheroapi.com/api.php/3525635500807579/1",
        type: "GET",
        dataType: "json",
        success: function (character){
            console.log(character);
             let {id, name, connections} = character;
            //  console.log(connections["group-affiliation"]);
        },
    });